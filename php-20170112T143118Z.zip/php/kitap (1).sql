-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 10 Oca 2017, 13:20:15
-- Sunucu sürümü: 10.1.16-MariaDB
-- PHP Sürümü: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `kitap`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `admin`
--

CREATE TABLE `admin` (
  `Id` int(11) NOT NULL,
  `telno` varchar(45) DEFAULT NULL,
  `adsoyad` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `sifre` varchar(30) DEFAULT NULL,
  `yetki` varchar(20) DEFAULT NULL,
  `durum` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Tablo döküm verisi `admin`
--

INSERT INTO `admin` (`Id`, `telno`, `adsoyad`, `email`, `sifre`, `yetki`, `durum`) VALUES
(15, '12', 'suat', 'suat@gmail.com', '123', NULL, NULL);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ayarlar`
--

CREATE TABLE `ayarlar` (
  `id` int(11) NOT NULL,
  `adi` varchar(255) COLLATE utf8_turkish_ci DEFAULT '',
  `keywords` varchar(200) COLLATE utf8_turkish_ci DEFAULT NULL,
  `aciklama` varchar(200) COLLATE utf8_turkish_ci DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_turkish_ci DEFAULT NULL,
  `smtpserver` varchar(200) COLLATE utf8_turkish_ci DEFAULT NULL,
  `smtpport` int(11) DEFAULT '0',
  `smtpemail` varchar(200) COLLATE utf8_turkish_ci DEFAULT NULL,
  `password` varchar(200) COLLATE utf8_turkish_ci DEFAULT NULL,
  `adres` varchar(200) COLLATE utf8_turkish_ci DEFAULT NULL,
  `sehir` varchar(200) COLLATE utf8_turkish_ci DEFAULT NULL,
  `tel` varchar(200) COLLATE utf8_turkish_ci DEFAULT NULL,
  `fax` varchar(200) COLLATE utf8_turkish_ci DEFAULT NULL,
  `email` varchar(200) COLLATE utf8_turkish_ci DEFAULT NULL,
  `hakkimizda` varchar(4000) COLLATE utf8_turkish_ci DEFAULT NULL,
  `iletisim` text COLLATE utf8_turkish_ci,
  `facebook` varchar(200) COLLATE utf8_turkish_ci DEFAULT NULL,
  `twitter` varchar(200) COLLATE utf8_turkish_ci DEFAULT NULL,
  `instagram` varchar(200) COLLATE utf8_turkish_ci DEFAULT NULL,
  `pinterest` varchar(200) COLLATE utf8_turkish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `ayarlar`
--

INSERT INTO `ayarlar` (`id`, `adi`, `keywords`, `aciklama`, `name`, `smtpserver`, `smtpport`, `smtpemail`, `password`, `adres`, `sehir`, `tel`, `fax`, `email`, `hakkimizda`, `iletisim`, `facebook`, `twitter`, `instagram`, `pinterest`) VALUES
(1, 'SUAT KİTAP', 'kitap, dergi,  makale, felsefe, roman, aşk', 'Kitap bilgileri ve özetleri', 'SUAT ERKAN AŞ', 'ssl://smtp.googlemail.com', 465, 'karabuktest@gmail.com', 'Karabauk2016', '<p>suaterkan.com</p><p>10.yil</p>', 'GİRESUN', '555 555 55 55', '555 555 55 55', 'bilgi@kitap.com', '<h2>Nereden Gelir?</h2>\r\n\r\n<p>Yaygın inancın tersine, Lorem Ipsum rastgele sözcüklerden oluşmaz. Kökleri M.Ö. 45 tarihinden bu yana klasik Latin edebiyatına kadar uzanan 2000 yıllık bir geçmişi vardır. Virginia&#39;daki Hampden-Sydney College&#39;dan Latince profesörü Richard McClintock, bir Lorem Ipsum pasajında geçen ve anlaşılması en güç sözcüklerden biri olan &#39;consectetur&#39; sözcüğünün klasik edebiyattaki örneklerini incelediğinde kesin bir kaynağa ulaşmıştır. Lorm Ipsum, Çiçero tarafından M.Ö. 45 tarihinde kaleme alınan "de Finibus Bonorum et Malorum" (İyi ve Kötünün Uç Sınırları) eserinin 1.10.32 ve 1.10.33 sayılı bölümlerinden gelmektedir. Bu kitap, ahlak kuramı üzerine bir tezdir ve Rönesans döneminde çok popüler olmuştur. Lorem Ipsum pasajının ilk satırı olan "Lorem ipsum dolor sit amet" 1.10.32 sayılı bölümdeki bir satırdan gelmektedir.</p>\r\n\r\n<p>1500&#39;lerden beri kullanılmakta olan standard Lorem Ipsum metinleri ilgilenenler için yeniden üretilmiştir. Çiçero tarafından yazılan 1.10.32 ve 1.10.33 bölümleri de 1914 H. Rackham çevirisinden alınan İngilizce sürümleri eşliğinde özgün biçiminden yeniden üretilmiştir.</p>\r\n', 'Her zaman ulaşabilirsiniz...', 'erkansuatt', 'erkansuat', 'suaterkan', 'suaterkan');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kisiler`
--

CREATE TABLE `kisiler` (
  `id` int(11) NOT NULL,
  `telno` varchar(45) CHARACTER SET latin1 DEFAULT NULL,
  `adsoyad` varchar(30) COLLATE utf8_turkish_ci DEFAULT NULL,
  `email` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `sifre` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `yetki` varchar(20) CHARACTER SET utf8 DEFAULT '2',
  `durum` varchar(20) CHARACTER SET utf8 DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `kisiler`
--

INSERT INTO `kisiler` (`id`, `telno`, `adsoyad`, `email`, `sifre`, `yetki`, `durum`) VALUES
(10, '55522200', 'serr', 'suat.erkawasn@hotmail.com', '123', '2', '2'),
(11, '12345678', 'jjjj', 'jjjj@hotmail.com', '123', '2', '2'),
(13, '123456786', 'jjjj', 'jjjertj@hotmail.com', '123', '2', '1'),
(15, '12345678', 'rasim ahmet', 'rasim@gmail.com', '123', '2', '1'),
(16, '5057033525', 'suat erkan', 'suat.erkan@gmail.com', '1235', '1', 'Aktif'),
(19, '263545', 'bugra', 'bugra@gmail.com', '123', '1', '1'),
(27, '123', 'dsdsd', 'ssd@gmail.com', '123', '2', '1'),
(28, '5052525566', 'deneme deneme', 'suat.erkan@outlook.com', '123', '2', '1');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kitaplar`
--

CREATE TABLE `kitaplar` (
  `id` int(100) NOT NULL,
  `adsoyad` varchar(80) COLLATE utf8_turkish_ci NOT NULL,
  `turu` varchar(40) COLLATE utf8_turkish_ci NOT NULL,
  `kategori_id` int(100) NOT NULL,
  `kisaaciklama` text COLLATE utf8_turkish_ci NOT NULL,
  `resim` varchar(256) CHARACTER SET latin1 NOT NULL,
  `durum` varchar(100) COLLATE utf8_turkish_ci NOT NULL,
  `galeri` varchar(256) COLLATE utf8_turkish_ci DEFAULT NULL,
  `yazaradi` varchar(200) COLLATE utf8_turkish_ci DEFAULT NULL,
  `adi` varchar(200) COLLATE utf8_turkish_ci NOT NULL,
  `uzunaciklama` varchar(2500) COLLATE utf8_turkish_ci NOT NULL,
  `aciklama` varchar(250) COLLATE utf8_turkish_ci NOT NULL,
  `keywords` varchar(200) COLLATE utf8_turkish_ci NOT NULL,
  `gonder` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `kitaplar`
--

INSERT INTO `kitaplar` (`id`, `adsoyad`, `turu`, `kategori_id`, `kisaaciklama`, `resim`, `durum`, `galeri`, `yazaradi`, `adi`, `uzunaciklama`, `aciklama`, `keywords`, `gonder`) VALUES
(9, 'Yaşam', 'Fantastik', 0, 'ateş ve ateş', 'platon11.jpg', '', NULL, 'Suat Erkan', '', '<p><strong>Lorem Ipsum</strong>, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, adı bilinmeyen bir matbaacının bir hurufat numune kitabı oluşturmak üzere bir yazı galerisini alarak karıştırdığı 1500&#39;lerden beri endüstri standardı sahte metinler olarak kullanılmıştır. Beşyüz yıl boyunca varlığını sürdürmekle kalmamış, aynı zamanda pek değişmeden elektronik dizgiye de sıçramıştır. 1960&#39;larda Lorem Ipsum pasajları da içeren Letraset yapraklarının yayınlanması ile ve yakın zamanda Aldus PageMaker gibi Lorem Ipsum sürümleri içeren masaüstü yayıncılık yazılımları ile popüler olmuştur.</p>\r\n', 'suat1suat2suat3sualjfdhuf', '', 0),
(11, 'Dünya', 'romantik', 0, 'bla bla', '250fe14a0184f82b9802c89e5bf0ab2e19e8adf8.jpg', '', '', 'mehmet mehmet', '', '<p><strong>Lorem Ipsum</strong>, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, adı bilinmeyen bir matbaacının bir hurufat numune kitabı oluşturmak üzere bir yazı galerisini alarak karıştırdığı 1500&#39;lerden beri endüstri standardı sahte metinler olarak kullanılmıştır. Beşyüz yıl boyunca varlığını sürdürmekle kalmamış, aynı zamanda pek değişmeden elektronik dizgiye de sıçramıştır. 1960&#39;larda Lorem Ipsum pasajları da içeren Letraset yapraklarının yayınlanması ile ve yakın zamanda Aldus PageMaker gibi Lorem Ipsum sürümleri içeren masaüstü yayıncılık yazılımları ile popüler olmuştur.</p>\r\n', '', '', 0),
(14, 'Su', 'Tarih', 0, 'assdsdsd asdsd', 'f02783c3299cc12c7261125e48871ca1.jpg', '', '', 'ahmet ahmet', '', '<h2>Neden Kullanırız?</h2>\r\n\r\n<p>Yinelenen bir sayfa içeriğinin okuyucunun dikkatini dağıttığı bilinen bir gerçektir. Lorem Ipsum kullanmanın amacı, sürekli &#39;buraya metin gelecek, buraya metin gelecek&#39; yazmaya kıyasla daha dengeli bir harf dağılımı sağlayarak okunurluğu artırmasıdır. Şu anda birçok masaüstü yayıncılık paketi ve web sayfa düzenleyicisi, varsayılan mıgır metinler olarak Lorem Ipsum kullanmaktadır. Ayrıca arama motorlarında &#39;lorem ipsum&#39; anahtar sözcükleri ile arama yapıldığında henüz tasarım aşamasında olan çok sayıda site listelenir. Yıllar içinde, bazen kazara, bazen bilinçli olarak (örneğin mizah katılarak), çeşitli sürümleri geliştirilmiştir.</p>\r\n', '', '', 0),
(15, 'Yaşam', 'selam merhaba', 0, 'sxfefaeax', '7188611437_a8d62e00ac_z.jpg', '', '', 'Selam selam', '', '<h2>Neden Kullanırız?</h2>\r\n\r\n<p>Yinelenen bir sayfa içeriğinin okuyucunun dikkatini dağıttığı bilinen bir gerçektir. Lorem Ipsum kullanmanın amacı, sürekli &#39;buraya metin gelecek, buraya metin gelecek&#39; yazmaya kıyasla daha dengeli bir harf dağılımı sağlayarak okunurluğu artırmasıdır. Şu anda birçok masaüstü yayıncılık paketi ve web sayfa düzenleyicisi, varsayılan mıgır metinler olarak Lorem Ipsum kullanmaktadır. Ayrıca arama motorlarında &#39;lorem ipsum&#39; anahtar sözcükleri ile arama yapıldığında henüz tasarım aşamasında olan çok sayıda site listelenir. Yıllar içinde, bazen kazara, bazen bilinçli olarak (örneğin mizah katılarak), çeşitli sürümleri geliştirilmiştir.</p>\r\n', '', '', 0),
(16, 'Harry Potter', 'Fantastik', 0, 'bla bla', 'hp1.png', 'Boş', NULL, 'J. K. Rowling', '', '<h2>Neden Kullanırız?</h2>\r\n\r\n<p>Yinelenen bir sayfa içeriğinin okuyucunun dikkatini dağıttığı bilinen bir gerçektir. Lorem Ipsum kullanmanın amacı, sürekli &#39;buraya metin gelecek, buraya metin gelecek&#39; yazmaya kıyasla daha dengeli bir harf dağılımı sağlayarak okunurluğu artırmasıdır. Şu anda birçok masaüstü yayıncılık paketi ve web sayfa düzenleyicisi, varsayılan mıgır metinler olarak Lorem Ipsum kullanmaktadır. Ayrıca arama motorlarında &#39;lorem ipsum&#39; anahtar sözcükleri ile arama yapıldığında henüz tasarım aşamasında olan çok sayıda site listelenir. Yıllar içinde, bazen kazara, bazen bilinçli olarak (örneğin mizah katılarak), çeşitli sürümleri geliştirilmiştir.</p>\r\n', '', '', 0),
(17, 'Yüzüklerin Efendisi', 'Fantastik', 0, 'bla bla', 'HDRO_Duesterwald_Packshot_Add-On1-265x379.jpg', 'Boş', NULL, 'J. R. R. Tolkien', '', '<h2>Neden Kullanırız?</h2>\r\n\r\n<p>Yinelenen bir sayfa içeriğinin okuyucunun dikkatini dağıttığı bilinen bir gerçektir. Lorem Ipsum kullanmanın amacı, sürekli &#39;buraya metin gelecek, buraya metin gelecek&#39; yazmaya kıyasla daha dengeli bir harf dağılımı sağlayarak okunurluğu artırmasıdır. Şu anda birçok masaüstü yayıncılık paketi ve web sayfa düzenleyicisi, varsayılan mıgır metinler olarak Lorem Ipsum kullanmaktadır. Ayrıca arama motorlarında &#39;lorem ipsum&#39; anahtar sözcükleri ile arama yapıldığında henüz tasarım aşamasında olan çok sayıda site listelenir. Yıllar içinde, bazen kazara, bazen bilinçli olarak (örneğin mizah katılarak), çeşitli sürümleri geliştirilmiştir.</p>\r\n', '', '', 0),
(18, 'Hobbit', 'Fantastik', 0, 'ssss', 'estreno-de-el-hobbit-undo.jpg', '', NULL, 'J. R. R. Tolkien', '', '<p>"Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?"</p>\r\n', '', '', 0),
(19, 'Semerkand', 'Tarih', 0, 'asdf', 'KB9786055506315.JPG', '', NULL, 'Amin Maalouf', '', '<p>"Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?"</p>\r\n', '', '', 0),
(20, 'ABCDBC', 'seddfdf', 0, 'sadsd', 'createfuturereadyclassroomsnow-265.jpg', 'Boş', NULL, 'asd', '', 'sdsdsdsdsdsdsd', '', '', 0),
(21, '12345', 'asdcvb', 0, 'asdsdsdsdsdsdsd', 'f37f3293b6686c0d8565659fb7f33975.jpg', 'Boş', NULL, 'werty', '', '<h2>Neden Kullanırız?</h2>\r\n\r\n<p>Yinelenen bir sayfa içeriğinin okuyucunun dikkatini dağıttığı bilinen bir gerçektir. Lorem Ipsum kullanmanın amacı, sürekli &#39;buraya metin gelecek, buraya metin gelecek&#39; yazmaya kıyasla daha dengeli bir harf dağılımı sağlayarak okunurluğu artırmasıdır. Şu anda birçok masaüstü yayıncılık paketi ve web sayfa düzenleyicisi, varsayılan mıgır metinler olarak Lorem Ipsum kullanmaktadır. Ayrıca arama motorlarında &#39;lorem ipsum&#39; anahtar sözcükleri ile arama yapıldığında henüz tasarım aşamasında olan çok sayıda site listelenir. Yıllar içinde, bazen kazara, bazen bilinçli olarak (örneğin mizah katılarak), çeşitli sürümleri geliştirilmiştir.</p>\r\n', '', '', 0),
(22, 'qwwerq', 'wewewdddd', 0, 'csdcsdcz', '9783897023932_1438382913000_xxl.jpg', 'Boş', NULL, 'wwqewqe', '', '<h2>Nereden Bulabilirim?</h2>\r\n\r\n<p>Lorem Ipsum pasajlarının birçok çeşitlemesi vardır. Ancak bunların büyük bir çoğunluğu mizah katılarak veya rastgele sözcükler eklenerek değiştirilmişlerdir. Eğer bir Lorem Ipsum pasajı kullanacaksanız, metin aralarına utandırıcı sözcükler gizlenmediğinden emin olmanız gerekir. İnternet&#39;teki tüm Lorem Ipsum üreteçleri önceden belirlenmiş metin bloklarını yineler. Bu da, bu üreteci İnternet üzerindeki gerçek Lorem Ipsum üreteci yapar. Bu üreteç, 200&#39;den fazla Latince sözcük ve onlara ait cümle yapılarını içeren bir sözlük kullanır.</p>\r\n', '', '', 0),
(23, 'Bilim Teknik', 'Bilim', 0, 'bunlar', 'teachingstudentstothinklikescientists.jpg', 'Dolu', NULL, 'Suat Erkan', '', '<p><strong>Lorem Ipsum</strong>, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, adı bilinmeyen bir matbaacının bir hurufat numune kitabı oluşturmak üzere bir yazı galerisini alarak karıştırdığı 1500&#39;lerden beri endüstri standardı sahte metinler olarak kullanılmıştır. Beşyüz yıl boyunca varlığını sürdürmekle kalmamış, aynı zamanda pek değişmeden elektronik dizgiye de sıçramıştır. 1960&#39;larda Lorem Ipsum pasajları da içeren Letraset yapraklarının yayınlanması ile ve yakın zamanda Aldus PageMaker gibi Lorem Ipsum sürümleri içeren masaüstü yayıncılık yazılımları ile popüler olmuştur.</p>\r\n', '', '', 0),
(24, 'Yaşama Tutunmak', 'romantik', 0, 'aşk acısı', '1-9783942270380_1439119807000_xxl.jpg', '', NULL, 'Akif Güldemir', '', '<p>"Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?"</p>\r\n', '', '', 0),
(25, 'korku', 'Felsefe', 0, 'asdassd', '6-38925641844812354_19c7a650_c1.jpg', '', NULL, 'MEHMET mehmet', '', '<p>"Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?"</p>\r\n', '', '', 0),
(26, 'adalet', 'sağlık', 0, 'asdf', '3-red-dog-tue-blue-cinema-australia.jpg', '', NULL, 'ali ali', '', '<p>"Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?"</p>\r\n', '', '', 0),
(27, 'merhaba', 'ders', 0, 'dersssss', '4-site1.jpg', '', NULL, 'J. R. R. Tolkien', '', '<p>"Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?"</p>\r\n', '', '', 0),
(28, 'Akıl', 'korku', 0, 'hastane', '5-9a1382494035792cab299bfb787e6e82.jpg', '', NULL, 'ahmet mehmet', '', '<p>"Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?"</p>\r\n', '', '', 0),
(29, 'Devlet', 'Fantastik', 0, 'bla bla', '6-38925641844812354_19c7a650_c.jpg', '', NULL, 'Suat Erkan', '', '<p>"Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?"</p>\r\n', '', '', 0),
(30, 'Yaşam', 'romantik', 0, 'ssss', '7-InfoCover2.png', '', NULL, 'J. R. R. Tolkien', '', '<p>"Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?"</p>\r\n', '', '', 0),
(31, 'Yaşam', 'Felsefe', 0, 'asdassd', '8-CwSQ_0bWEAER6m3.jpg', '', NULL, 'J. R. R. Tolkien', '', '<p>"Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?"</p>\r\n', '', '', 0),
(32, 'Semerkand', 'ince', 0, 'lalala', 'unitingacademicbehaviorint-265.jpg', '', NULL, 'J. K. Rowling', '', '<p>"Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?"</p>\r\n', '', '', 0),
(33, 'asdas', 'adasd', 0, 'adsad', '', '0', NULL, 'adsas', '', '<p>asdasd</p>\r\n', '', '', 1),
(34, 'dasd', 'asd', 0, 'asd', 'platon12.jpg', '', NULL, 'ad', '', 'adasd', '', '', 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kitaplar_resim`
--

CREATE TABLE `kitaplar_resim` (
  `kitap_id` int(240) DEFAULT NULL,
  `resim` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `id` int(11) NOT NULL,
  `adi` varchar(200) COLLATE utf8_turkish_ci NOT NULL,
  `aciklama` varchar(200) COLLATE utf8_turkish_ci NOT NULL,
  `keywords` varchar(200) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `kitaplar_resim`
--

INSERT INTO `kitaplar_resim` (`kitap_id`, `resim`, `id`, `adi`, `aciklama`, `keywords`) VALUES
(6, 'suat.jpg', 1, '', 'asdfadfafdafdafdsf', ''),
(7, 'MAIL4.jpg', 3, '', '', ''),
(6, 'Wxo6AXx61.jpg', 5, '', '', ''),
(6, 'Wxo6AXx62.jpg', 6, '', '', ''),
(6, '64298-_6_suat_ertan_copy_(1)1.jpg', 7, '', '', ''),
(8, 'platon1.jpg', 9, '', '', ''),
(8, 'platon2.jpg', 10, '', '', ''),
(12, 'MAIL6.jpg', 11, '', '', ''),
(14, 'platon4.jpg', 14, '', '', ''),
(11, 'lets-learn-to-count-book-with-brian-mclion-hand-puppet-Front-1.jpg', 17, '', '', ''),
(9, 'TTG01.JPG', 18, '', '', ''),
(23, 'createfuturereadyclassroomsnow-2651.jpg', 19, '', '', ''),
(15, '2016_DSFB_2719-265x380.jpg', 20, '', '', ''),
(16, '12352651.jpg', 21, '', '', ''),
(25, 'HDRO_Duesterwald_Packshot_Add-On1-265x3791.jpg', 22, '', '', ''),
(22, '5-9a1382494035792cab299bfb787e6e821.jpg', 23, '', '', ''),
(21, '2-image0101.jpg', 24, '', '', ''),
(20, '8-CwSQ_0bWEAER6m31.jpg', 25, '', '', ''),
(18, 'createfuturereadyclassroomsnow-2652.jpg', 26, '', '', ''),
(17, '7188611437_a8d62e00ac_z1.jpg', 27, '', '', ''),
(32, '7-InfoCover21.png', 28, '', '', ''),
(31, '250fe14a0184f82b9802c89e5bf0ab2e19e8adf81.jpg', 29, '', '', ''),
(30, '123526511.jpg', 30, '', '', ''),
(29, '5-9a1382494035792cab299bfb787e6e822.jpg', 31, '', '', ''),
(28, '3-red-dog-tue-blue-cinema-australia1.jpg', 32, '', '', ''),
(27, '2016_DSFB_2719-265x3801.jpg', 33, '', '', ''),
(24, '8-CwSQ_0bWEAER6m32.jpg', 34, '', '', ''),
(19, 'f02783c3299cc12c7261125e48871ca11.jpg', 35, '', '', '');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `mesajlar`
--

CREATE TABLE `mesajlar` (
  `id` int(11) NOT NULL,
  `ad` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `mail` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `mesaj` text COLLATE utf8_turkish_ci NOT NULL,
  `durum` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `mesajlar`
--

INSERT INTO `mesajlar` (`id`, `ad`, `mail`, `mesaj`, `durum`) VALUES
(1, 'suat ', 'suat.erkan@gmail.com', 'asdas', 0),
(3, 'ahmet ahmet', 'suat.erkan@outlook.com', '"Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?"', 0),
(4, 'selam', 'suat.erkan@outlook.com', 'assdasdssd', 0);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `slider`
--

CREATE TABLE `slider` (
  `id` int(11) NOT NULL,
  `resim` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `sira` int(11) NOT NULL,
  `durum` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `slider`
--

INSERT INTO `slider` (`id`, `resim`, `sira`, `durum`) VALUES
(1, '64298-_6_suat_ertan_copy2.jpg', 1, 1),
(2, 'MAIL6.jpg', 2, 2),
(3, 'platon22.jpg', 3, 1),
(5, 'lets-learn-to-count-book-with-brian-mclion-hand-puppet-Front-11.jpg', 5, 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `sss`
--

CREATE TABLE `sss` (
  `id` int(11) NOT NULL,
  `baslik` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `aciklama` text COLLATE utf8_turkish_ci NOT NULL,
  `durum` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `sss`
--

INSERT INTO `sss` (`id`, `baslik`, `aciklama`, `durum`) VALUES
(1, 'Üyelik Sorunu', '<p>Tarayıcınızdan kaynaklıdır. En iyi seçenek için Chrome Web Tarayıcı öneriyoruz.</p>\r\n', 1),
(3, 'dneem3', '<p>deenem2 cevabnı</p>\r\n', 1),
(4, 'Güncelleme kaynaklı', '<p>1500&#39;lerden beri kullanılmakta olan standard Lorem Ipsum metinleri ilgilenenler için yeniden üretilmiştir. Çiçero tarafından yazılan 1.10.32 ve 1.10.33 bölümleri de 1914 H. Rackham çevirisinden alınan İngilizce sürümleri eşliğinde özgün biçiminden yeniden üretilmiştir.</p>\r\n', 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `yorumlar`
--

CREATE TABLE `yorumlar` (
  `id` int(11) NOT NULL,
  `kisiId` int(11) NOT NULL,
  `kitapId` int(11) NOT NULL,
  `yorum` text COLLATE utf8_turkish_ci NOT NULL,
  `tarih` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `yorumlar`
--

INSERT INTO `yorumlar` (`id`, `kisiId`, `kitapId`, `yorum`, `tarih`) VALUES
(4, 16, 9, 'denem', '2017-01-06 21:03:21'),
(5, 16, 12, 'Mğkemem', '2017-01-06 22:15:42'),
(6, 15, 11, 'selam çok güzel ötesi olmuş :)', '2017-01-09 19:14:57'),
(7, 15, 9, 'merhabalarrrr', '2017-01-10 02:01:48');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Id`);

--
-- Tablo için indeksler `ayarlar`
--
ALTER TABLE `ayarlar`
  ADD PRIMARY KEY (`id`),
  ADD KEY `adi` (`adi`);

--
-- Tablo için indeksler `kisiler`
--
ALTER TABLE `kisiler`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`) USING BTREE;

--
-- Tablo için indeksler `kitaplar`
--
ALTER TABLE `kitaplar`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `kitaplar_resim`
--
ALTER TABLE `kitaplar_resim`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `mesajlar`
--
ALTER TABLE `mesajlar`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `sss`
--
ALTER TABLE `sss`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `yorumlar`
--
ALTER TABLE `yorumlar`
  ADD PRIMARY KEY (`id`),
  ADD KEY `kitapId` (`kitapId`),
  ADD KEY `uyeId` (`kisiId`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `admin`
--
ALTER TABLE `admin`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `ayarlar`
--
ALTER TABLE `ayarlar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Tablo için AUTO_INCREMENT değeri `kisiler`
--
ALTER TABLE `kisiler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- Tablo için AUTO_INCREMENT değeri `kitaplar`
--
ALTER TABLE `kitaplar`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
--
-- Tablo için AUTO_INCREMENT değeri `kitaplar_resim`
--
ALTER TABLE `kitaplar_resim`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- Tablo için AUTO_INCREMENT değeri `mesajlar`
--
ALTER TABLE `mesajlar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- Tablo için AUTO_INCREMENT değeri `slider`
--
ALTER TABLE `slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- Tablo için AUTO_INCREMENT değeri `sss`
--
ALTER TABLE `sss`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- Tablo için AUTO_INCREMENT değeri `yorumlar`
--
ALTER TABLE `yorumlar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
